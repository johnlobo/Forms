;;-----------------------------LICENSE NOTICE------------------------------------
;;
;;  This program is free software: you can redistribute it and/or modify
;;  it under the terms of the GNU Lesser General Public License as published by
;;  the Free Software Foundation, either version 3 of the License, or
;;  (at your option) any later version.
;;
;;  This program is distributed in the hope that it will be useful,
;;  but WITHOUT ANY WARRANTY; without even the implied warranty of
;;  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;;  GNU Lesser General Public License for more details.
;;
;;  You should have received a copy of the GNU Lesser General Public License
;;  along with this program.  If not, see <http://www.gnu.org/licenses/>.
;;-------------------------------------------------------------------------------



;;------------------------------------------------------------------------------
;; Global variables
;;------------------------------------------------------------------------------
.globl board
.globl board_row_addresses
;;------------------------------------------------------------------------------
;; Global routines
;;------------------------------------------------------------------------------
.globl sys_board_init
.globl sys_board_cell_content
.globl sys_board_cell_sprite
.globl sys_board_set_piece
.globl sys_board_check_partial_rows
.globl sys_board_erase_row
.globl sys_board_check_partial_cols
.globl sys_board_erase_col
.globl sys_board_valid_place
.globl sys_board_any_space